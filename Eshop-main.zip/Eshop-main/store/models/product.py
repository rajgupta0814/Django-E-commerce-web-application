from django.db import models
from .category import Category
from PIL import Image
class Products(models.Model):
    name = models.CharField(max_length=60)
    price= models.IntegerField(default=0)
    category= models.ForeignKey(Category,on_delete=models.CASCADE,default=1 )
    description= models.CharField(max_length=250, default='', blank=True, null= True)
    image= models.ImageField(upload_to='uploads/products/')



    def save(self, *args, **kwargs):

        # Define the desired image size (e.g., 300x200)
        desired_width = 300
        desired_height = 200

        super().save(*args, **kwargs)

        # Open the uploaded image
        image = Image.open(self.image.path)

        # Resize the image
        image = image.resize((desired_width, desired_height), Image.LANCZOS)

        # Save the resized image back to the same path
        image.save(self.image.path)

    @staticmethod
    def get_products_by_id(ids):
        return Products.objects.filter (id__in=ids)
    @staticmethod
    def get_all_products():
        return Products.objects.all()

    @staticmethod
    def get_all_products_by_categoryid(category_id):
        if category_id:
            return Products.objects.filter (category=category_id)
        else:
            return Products.get_all_products();